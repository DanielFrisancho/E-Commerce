﻿Public Class LineaProducto
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim linea1 As New CapaNegocio.LineaProducto
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        linea1.Cantidad = txtCantidad.Text.Trim
        linea1.Precio = txtPrecio.Text.Trim
        Response.Write("se ha agregado correctamente")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Dim Datos As String
        Datos = "Cantidad: " + linea1.Cantidad + " Precio: " + linea1.Precio
        MsgBox(Datos)
    End Sub

    Protected Sub btnOrganizarProductos_Click(sender As Object, e As EventArgs) Handles btnOrganizarProductos.Click
        Response.Write(linea1.OrganizarProductos())
    End Sub
End Class