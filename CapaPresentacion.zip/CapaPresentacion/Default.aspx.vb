﻿Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub btnPago_Click(sender As Object, e As EventArgs) Handles btnPago.Click
        Response.Redirect("Pago.aspx")
    End Sub

    Protected Sub btnEnvio_Click(sender As Object, e As EventArgs) Handles btnEnvio.Click
        Response.Redirect("Envio.aspx")
    End Sub

    Protected Sub btnPedido_Click(sender As Object, e As EventArgs) Handles btnPedido.Click
        Response.Redirect("Pedido.aspx")
    End Sub

    Protected Sub btnCliente_Click(sender As Object, e As EventArgs) Handles btnCliente.Click
        Response.Redirect("Cliente.aspx")
    End Sub

    Protected Sub btnCarritoCompra_Click(sender As Object, e As EventArgs) Handles btnCarritoCompra.Click
        Response.Redirect("CarritoCompra.aspx")
    End Sub

    Protected Sub btnLineaProducto_Click(sender As Object, e As EventArgs) Handles btnLineaProducto.Click
        Response.Redirect("LineaProducto.aspx")
    End Sub

    Protected Sub btnProducto_Click(sender As Object, e As EventArgs) Handles btnProducto.Click
        Response.Redirect("Producto.aspx")
    End Sub
End Class