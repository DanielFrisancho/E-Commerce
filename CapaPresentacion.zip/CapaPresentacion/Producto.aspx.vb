﻿Public Class Producto
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim producto1 As New CapaNegocio.Producto
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        producto1.Id = txtId.Text.Trim
        producto1.Denominacion = txtDenominacion.Text.Trim
        producto1.Proveedor = txtProveedor.Text.Trim
        Response.Write("se ha agregado correctamente")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Dim Datos As String
        Datos = "ID: " + producto1.Id + " Denominacion: " + producto1.Denominacion + " Proveedor: " + producto1.Proveedor
        MsgBox(Datos)
    End Sub

    Protected Sub btnSolicitarStock_Click(sender As Object, e As EventArgs) Handles btnSolicitarStock.Click
        Response.Write(producto1.SolicitarStock())
    End Sub

    Protected Sub btnBeneficiarCliente_Click(sender As Object, e As EventArgs) Handles btnBeneficiarCliente.Click
        Response.Write(producto1.BeneficiarCliente())
    End Sub
End Class