﻿Public Class Cliente
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim cliente1 As New CapaNegocio.Cliente
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        cliente1.Id = txtId.Text.Trim
        cliente1.Direccion = txtDireccion.Text.Trim
        cliente1.Telefono = txtTelefono.Text.Trim
        cliente1.Email = txtEmail.Text.Trim
        Response.Write("se ha agregado correctamente")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Dim Datos As String
        Datos = "ID: " + cliente1.Id + " Direccion: " + cliente1.Direccion + " Telefono: " + cliente1.Telefono + " Email: " + cliente1.Email
        MsgBox(Datos)
    End Sub

    Protected Sub btnComprar_Click(sender As Object, e As EventArgs) Handles btnComprar.Click
        Response.Write(cliente1.Comprar())
    End Sub

    Protected Sub btnPagar_Click(sender As Object, e As EventArgs) Handles btnPagar.Click
        Response.Write(cliente1.Pagar())
    End Sub

    Protected Sub btnRecepcionarProducto_Click(sender As Object, e As EventArgs) Handles btnRecepcionarProducto.Click
        Response.Write(cliente1.RecepcionarProducto())
    End Sub

    Protected Sub btnCanjear_Click(sender As Object, e As EventArgs) Handles btnCanjear.Click
        Response.Write(cliente1.Canjear())
    End Sub
End Class