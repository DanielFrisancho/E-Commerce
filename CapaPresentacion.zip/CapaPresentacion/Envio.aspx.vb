﻿Public Class Envio
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim envio1 As New CapaNegocio.Envio
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        envio1.Id = txtId.Text.Trim
        envio1.DireccionFacturacion = txtDireccionFacturacion.Text.Trim
        envio1.Finalizado = txtFinalizado.Text.Trim
        envio1.FechaEnvio = calFechaEnvio.SelectedDate
        envio1.Compania = txtCompania.Text.Trim
        Response.Write("se ha agregado correctamente")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Dim Datos As String
        Datos = "ID: " + envio1.Id + " Direccion de Facturacion: " + envio1.DireccionFacturacion + " Finalizado: " + envio1.Finalizado + " Fecha de envio: " + envio1.FechaEnvio.ToString + " Compania: " + envio1.Compania
        MsgBox(Datos)
    End Sub

    Protected Sub btnLlevarProducto_Click(sender As Object, e As EventArgs) Handles btnLlevarProducto.Click
        Response.Write(envio1.LlevarProducto())
    End Sub

    Protected Sub calFechaEnvio_SelectionChanged(sender As Object, e As EventArgs) Handles calFechaEnvio.SelectionChanged

    End Sub
End Class