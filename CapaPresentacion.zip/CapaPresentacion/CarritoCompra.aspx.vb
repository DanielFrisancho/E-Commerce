﻿Public Class CarritoCompra
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim carrito1 As New CapaNegocio.CarritoCompra
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        carrito1.FechaCreacion = calFechaCreacion.SelectedDate
        Response.Write("se ha agregado correctamente")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Dim Datos As String
        Datos = "Fecha de Creacion: " + carrito1.FechaCreacion.ToString
        MsgBox(Datos)
    End Sub

    Protected Sub btnAlmacenarProductos_Click(sender As Object, e As EventArgs) Handles btnAlmacenarProductos.Click
        Response.Write(carrito1.AlmacenarProductos())
    End Sub

    Protected Sub btnVerificarStock_Click(sender As Object, e As EventArgs) Handles btnVerificarStock.Click
        Response.Write(carrito1.VerificarStock())
    End Sub
End Class