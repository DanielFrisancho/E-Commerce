﻿Public Class Pedido
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim pedido1 As New CapaNegocio.Pedido
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        pedido1.Id = txtId.Text.Trim
        pedido1.FechaRealizacion = calFechaRealizacion.SelectedDate
        pedido1.Estado = txtEstado.Text.Trim
        pedido1.Total = txtTotal.Text.Trim
        Response.Write("se ha agregado correctamente")
    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Dim Datos As String
        Datos = "ID: " + pedido1.Id + " Fecha Realizacion: " + pedido1.FechaRealizacion.ToString + " Estado: " + pedido1.Estado + " Total: " + pedido1.Total
        MsgBox(Datos)
    End Sub

    Protected Sub btnSeleccionarProducto_Click(sender As Object, e As EventArgs) Handles btnSeleccionarProducto.Click
        Response.Write(pedido1.SeleccionarProducto())
    End Sub
End Class