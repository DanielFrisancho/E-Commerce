﻿Public Class Pago
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
    Dim pago1 As New CapaNegocio.Pago
    Protected Sub btnLeer_Click(sender As Object, e As EventArgs) Handles btnLeer.Click
        pago1.Id = txtId.Text.Trim
        pago1.FechaPago = calFechaPago.TodaysDate
        pago1.Paga = txtPaga.Text.Trim
        Response.Write("se ha agregado correctamente")

    End Sub

    Protected Sub btnEscribir_Click(sender As Object, e As EventArgs) Handles btnEscribir.Click
        Dim Datos As String
        Datos = "ID: " + pago1.Id + " Fecha de Pago: " + pago1.FechaPago.ToString + " Paga: " + pago1.Paga.ToString
        MsgBox(Datos)
    End Sub

    Protected Sub btnCobrar_Click(sender As Object, e As EventArgs) Handles btnCobrar.Click
        Response.Write(pago1.Cobrar())
    End Sub
End Class